package com.spase_y.playlistmaker05022024.settings.domain.model

data class ThemeSettings(
    val isDarkTheme: Boolean
)
