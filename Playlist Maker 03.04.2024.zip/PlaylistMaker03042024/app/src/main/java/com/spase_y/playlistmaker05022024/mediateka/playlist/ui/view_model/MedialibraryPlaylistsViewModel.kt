package com.spase_y.playlistmaker05022024.mediateka.playlist.ui.view_model

import androidx.lifecycle.ViewModel

class MedialibraryPlaylistsViewModel : ViewModel() {

}