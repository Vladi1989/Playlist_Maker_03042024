package com.spase_y.playlistmaker05022024.sharing.domain.api

interface SharingInteractor {
    fun shareApp()
    fun openTerms()
    fun openSupport()
}