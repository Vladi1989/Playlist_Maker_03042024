package com.spase_y.playlistmaker05022024.sharing.domain.model

data class EmailData(
    val email: String,
    val text: String,
    val subject: String
)
